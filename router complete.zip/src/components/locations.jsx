const Locations = () => {
    return ( <section>
        <h2>Comnpany's Locations</h2>
        <p>British Columbia</p>
        <p>Ontario</p>
    </section>  );
}
 
export default Locations;