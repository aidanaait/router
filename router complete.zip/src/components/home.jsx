const Home = () => {
  return (
    <div>
      <h1>My Shopping Website</h1>
      
    </div>
  );
};

export default Home;
