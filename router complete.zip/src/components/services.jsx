const Services = () => {
    return (  <section>
        <h2>Our Services</h2>
        <p>Lorem ipsum dolor, sit amet consectetur adipisicing elit. Ratione illum esse corrupti voluptas sequi, laudantium incidunt magni vero id, modi laborum consequuntur, necessitatibus natus soluta. Tempora, harum soluta! Nihil, dignissimos?</p>
    </section> );
}
 
export default Services;