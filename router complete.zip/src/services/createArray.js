export const createArray = (length) => {
  return [...Array(length)];
};
